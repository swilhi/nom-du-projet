#include <gtk/gtk.h>
  GtkWidget *acceuil;
  GtkWidget *gestion;
typedef struct{
char cin[30];
char nom[30];
char prenom[30];
char adresse[30];
char numtel[9];
}utilisateur;

typedef struct excursion excursion;
struct excursion{
char date_depart[30];
char date_retour[30];
char destination[30];
int nbPlaceDispo;
int prix;
};
int i,j,k;

void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ajouter_utilisateur_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_utilisateur_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Supprimer_utilisateur_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_utilisateur_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Reserver_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
