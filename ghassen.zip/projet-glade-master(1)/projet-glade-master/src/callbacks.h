#include <gtk/gtk.h>


void
on_buttonajouter_ghassen_clicked               (GtkWidget	 *objet_graphique,
                                        gpointer         user_data);

void
on_buttonafficher_ghassen_clicked              (GtkWidget	 *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifier_ghassen_clicked              (GtkWidget	 *objet_graphique,
                                        gpointer         user_data);

void
on_treeviewmenu_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonretour_ghassen_clicked                (GtkWidget	 *objet_graphique,
                                        gpointer         user_data);

void
on_buttongotomodifier_ghassen_clicked          (GtkWidget	 *objet_graphique,
                                        gpointer         user_data);

void
on_buttonrechercher_ghassen_clicked            (GtkWidget	 *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmeilleurmenu_ghassen_clicked          (GtkWidget	 *objet_graphique,
                                        gpointer         user_data);

void
on_buttongotomeilleurmenu_ghassen_clicked      (GtkWidget	 *objet_graphique,
                                        gpointer         user_data);



