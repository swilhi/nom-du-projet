

void Afficherproduit(GtkWidget* treeview1,char*l);
void Afficherproduit1(GtkWidget* treeview1,char*l);
int Chercherproduit(GtkWidget* treeview1,char*l,char*nom);
