
void ajouter_utilisateur( utilisateur c);
int exist_utilisateur(char*cin);
void supprimer_utilisateur(char*cin);
void ajouter_reservation(excursion e,int nb);
void modifier_excursion(excursion e,int nb);
