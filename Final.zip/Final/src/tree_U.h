

void Afficherutilisateur(GtkWidget* treeview1,char*l);
void Afficherutilisateur1(GtkWidget* treeview1,char*l);
void AfficherExcursion(GtkWidget* treeview1,char*l);
int Chercherutilisateur(GtkWidget* treeview1,char*l,char*nom);
