#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "callbacks.h"
#include <string.h>


void ajouter_utilisateur(utilisateur c){
FILE *f=NULL;
f=fopen("clients.txt","a+");//(+) creation du fichier sil nexsite pas
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel);
}
else{
return;
}
fclose(f);
}

int exist_utilisateur(char*cin){
FILE*f=NULL;
 utilisateur c;
f=fopen("clients.txt","r");
while(fscanf(f,"%s %s %s %s %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel)!=EOF){
if(strcmp(c.cin,cin)==0)return 1;
}
fclose(f);
return 0;
}


void supprimer_utilisateur(char*cin){
FILE*f=NULL;
FILE*f1=NULL;
utilisateur c ;
f=fopen("clients.txt","r");

f1=fopen("ancien.txt","w+");
while(fscanf(f,"%s %s %s %s %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel)!=EOF){
if(strcmp(cin,c.cin)!=0)fprintf(f1,"%s %s %s %s %s\n",c.cin,c.nom,c.prenom,c.adresse,c.numtel);
}
fclose(f);
fclose(f1);
remove("clients.txt");
rename("ancien.txt","clients.txt");
}



void ajouter_reservation(excursion e,int nb)//nb ==> valeur de spinButton
{
FILE*f=NULL;

excursion r;
f=fopen("reservation.txt","a+");
fprintf(f,"%s %s %s %d %d\n",e.date_depart,e.date_retour,e.destination,nb,e.prix);
fclose(f);


}

void modifier_excursion(excursion e,int nb){
FILE*f=NULL;
FILE*f1=NULL;
excursion c ;
f=fopen("excursions.txt","r");

f1=fopen("ancien.txt","w+");
while(fscanf(f,"%s %s %s %d %d\n",c.date_depart,c.date_retour,c.destination,&c.nbPlaceDispo,&c.prix)!=EOF){
if( strcmp(e.date_depart,c.date_depart)!=0 || strcmp(e.date_retour,c.date_retour)!=0 || strcmp(e.destination,c.destination)!=0 || e.nbPlaceDispo!=c.nbPlaceDispo || e.prix!=c.prix  )
{
fprintf(f1,"%s %s %s %d %d\n",c.date_depart,c.date_retour,c.destination,c.nbPlaceDispo,c.prix);
}
else
{
fprintf(f1,"%s %s %s %d %d\n",c.date_depart,c.date_retour,c.destination,c.nbPlaceDispo-nb,c.prix);
}

}
fclose(f);
fclose(f1);
remove("excursions.txt");
rename("ancien.txt","excursions.txt");
}














