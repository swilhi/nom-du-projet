#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"tree.h"
#include"CRUD.h"
FILE*f=NULL;
void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
/*preparation du treeView*/
GtkWidget *p;
GtkWidget *p1;
GtkWidget *p2;
gtk_widget_hide (acceuil);
gestion = create_gestion ();
p=lookup_widget(gestion,"treeview1");
p1=lookup_widget(gestion,"treeview2");
//p2=lookup_widget(gestion,"treeview3");
i=0;
j=0;
k=0;
Afficherproduit(p,"produits.txt");
Afficherproduit1(p1,"produits.txt");
gtk_widget_show (gestion);
}


void
on_Ajouterproduit_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
 produit c;
GtkWidget *entryNom;
GtkWidget *entryid;
GtkWidget *entryprix;
GtkWidget *entrydate_entree;
GtkWidget *entrydate_expiration;
GtkWidget *labelid;
GtkWidget *labelnom;
GtkWidget *labelprix;
GtkWidget *labeldate_entree;
GtkWidget *labeldate_expiration;
GtkWidget *existe;
GtkWidget* success;
GtkWidget *entryrangement;
GtkWidget *entryfour;
GtkWidget *labelfour;
int b=1;
 GtkWidget *cal;
 GtkWidget *cal2;
GtkWidget *calendar1 ; 
GtkWidget *calendar2 ; 
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *input9;
GtkWidget *input10;
GtkWidget *input11;
GtkWidget *input12;
GtkWidget *input13;

int jj, mm, aa;
int jj1, mm1, aa1;
int quantite; 
char q[20];

entryid=lookup_widget(gestion,"entry5"); //lookup tlawej 3la entry "entry5" fil window w t'affectiha ll ll entryid
entryNom=lookup_widget(gestion,"entry1");
entryprix=lookup_widget(gestion,"entry2");
entrydate_entree=lookup_widget(gestion,"entry4");
entrydate_expiration=lookup_widget(gestion,"entry3");
entryfour=lookup_widget(gestion,"entryfour");

labelfour=lookup_widget(gestion,"labelfour");
labelid=lookup_widget(gestion,"label13");
labelnom=lookup_widget(gestion,"label7");
labelprix=lookup_widget(gestion,"label8");
labeldate_entree=lookup_widget(gestion,"label9");
labeldate_expiration=lookup_widget(gestion,"label10");
existe=lookup_widget(gestion,"label34");
success=lookup_widget(gestion,"label35");
input7=lookup_widget(button,"spinbuttonquantity"); 
        
	
	quantite = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7)); 
	sprintf(q,"%d",quantite); // tconverti men entier l char
        strcpy(c.quantity,q);

        strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(entryid) ) );
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(entryNom) ) );
        strcpy(c.prix,gtk_entry_get_text(GTK_ENTRY(entryprix) ) );
strcpy(c.fournisseur,gtk_entry_get_text(GTK_ENTRY(entryfour) ) );


entryrangement=lookup_widget(gestion,"combobox1");
strcpy(c.rangement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryrangement)));


		


  input8=lookup_widget(button,"spinbuttonjoure"); 
input9=lookup_widget(button,"spinbuttonmoise");
input10=lookup_widget(button,"spinbuttonanneee");

  input11=lookup_widget(button,"spinbuttonjourex"); 
input12=lookup_widget(button,"spinbuttonmoisex");
input13=lookup_widget(button,"spinbuttonanneeex");



        c.date1.jour  = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
	c.date1.mois  = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));
	c.date1.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input10)); 

c.date2.jour  = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input11));
	c.date2.mois  = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input12));
	c.date2.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input13)); 



 gtk_widget_hide (success);
// controle saisie
if(strcmp(c.id,"")==0){
		  gtk_widget_show (labelid);
b=0;
}
else {
		  gtk_widget_hide(labelid);
}

if(strcmp(c.nom,"")==0){
		  gtk_widget_show (labelnom);
b=0;
}
else {
		  gtk_widget_hide(labelnom);
}
if(strcmp(c.prix,"")==0){
		  gtk_widget_show (labelprix);
b=0;
}
else {
		  gtk_widget_hide(labelprix);
}
/*if(strcmp(c.date_entree,"")==0){
		  gtk_widget_show (labeldate_entree);
b=0;
}
else {
		  gtk_widget_hide(labeldate_entree);
}
if(strcmp(c.date_expiration,"")==0){
		  gtk_widget_show (labeldate_expiration);
b=0;
}
else {
		  gtk_widget_hide(labeldate_expiration);
}


*/

if(strcmp(c.fournisseur,"")==0){
		  gtk_widget_show (labelfour);
b=0;
}
else {
		  gtk_widget_hide(labelfour);
}



if(b==1){

        if(exist_produit(c.id)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide(existe);

                        f = fopen("produits.txt", "a+");
                        fprintf(f, "%s %s %s %d/%d/%d %d/%d/%d %s %s %s\n", c.id,c.nom,c.prix,c.date1.annee,c.date1.mois,c.date1.jour,c.date2.annee,c.date2.mois,c.date2.jour,c.fournisseur,c.rangement,c.quantity);
                        fclose(f);
                       

                        gtk_widget_show(success);

                   
        }
//mise a jour du treeView
        GtkWidget* p=lookup_widget(gestion,"treeview1");

        Afficherproduit(p,"produits.txt");
}

}





void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)//signale du treeView (Double click)
{
	gchar *id;
        gchar *nom;
        gchar *prix;
        gchar *date_entree;
        gchar *date_expiration;
        gchar *fournisseur;
	gchar *rangement;
        gchar *quantity;
        int x;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(gestion,"treeview1");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {
		gtk_widget_hide(lookup_widget(gestion,"label37"));//cacher label modifier avec succees
		
                gtk_tree_model_get (model,&iter,0,&id,1,&nom,2,&prix,3,&date_entree,4,&date_expiration,5,&fournisseur,6,&rangement,7,&quantity,-1);//recuperer les information de la ligne selectionneé
		//remplir les champs de entry
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry6")),nom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry7")),prix);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry9")),date_entree);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry8")),date_expiration);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry_modif_four")),fournisseur);
		gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry_modif_quantity")),quantity);
          


                GtkWidget* msgid=lookup_widget(gestion,"label20");
                GtkWidget* msg1=lookup_widget(gestion,"label36");
                gtk_label_set_text(GTK_LABEL(msgid),id);
                gtk_widget_show(msgid);
                gtk_widget_show(msg1);
                gtk_widget_show(lookup_widget(gestion,"button4"));//afficher le bouton modifier
                gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(gestion,"notebook1")));//redirection vers la page precedente
        }



}


void
on_Supprimerproduit_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
   GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label;
        gchar* id;//gchar* type gtk ==> chaine en c car la fonction gtk_tree_model_get naccepte que gchar*
        label=lookup_widget(gestion,"label23");
        p=lookup_widget(gestion,"treeview1");




        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))//test sur la ligne selectionnée
        {  gtk_tree_model_get (model,&iter,0,&id,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supprimer_produit(id);// supprimer la ligne du fichier

           gtk_widget_hide (label);}
else{
                gtk_widget_show (label);
        }

}


void
on_chercherproduit_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelnom;
GtkWidget *nbResultat;
GtkWidget *message;
char nom[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(gestion,"entry10");
labelnom=lookup_widget(gestion,"label28");
p1=lookup_widget(gestion,"treeview2");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(entry)));

if(strcmp(nom,"")==0){
  gtk_widget_show (labelnom);b=0;
}else{
b=1;
gtk_widget_hide (labelnom);}

if(b==0){return;}else{

nb=Chercherproduit(p1,"produits.txt",nom);
/* afficher le nombre de resultats obtenue par la recherche */
sprintf(chnb,"%d",nb);//conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultat=lookup_widget(gestion,"label27");
message=lookup_widget(gestion,"label26");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);



}

}



void
on_Modifierproduit_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
     GtkWidget *combobox2;
     combobox2=lookup_widget(button,"combobox2");
 produit c;
int quantite ; 
char q[20];

        strcpy(c.id,gtk_label_get_text(GTK_LABEL(lookup_widget(gestion,"label20"))));
        strcpy(c.rangement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lookup_widget(gestion,"combobox2")))); 
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry6"))));
        strcpy(c.prix,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry7"))));
        strcpy(c.date_entree,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry9"))));
        strcpy(c.date_expiration,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry8"))));
        strcpy(c.fournisseur,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_modif_four"))));
strcpy(c.quantity,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry_modif_quantity"))));
        //quantite = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(lookup_widget(gestion,"spinbuttonquantity2"))); 
	

        // sprintf(q,"%d",quantite);
       // strcpy(c.quantity,q);
        supprimer_produit(c.id);
        ajouter_produit(c);
//mise ajour du tree view 
        Afficherproduit(lookup_widget(gestion,"treeview1"),"produits.txt");
		gtk_widget_show(lookup_widget(gestion,"label37"));

}

void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (acceuil);
gtk_widget_destroy (gestion);

}


