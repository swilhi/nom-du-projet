#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"tree.h"
#include"CRUD.h"


void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
/*preparation du treeView*/
GtkWidget *p;
GtkWidget *p1;
GtkWidget *p2;
gtk_widget_hide (acceuil);
gestion = create_gestion ();
/*p=lookup_widget(gestion,"treeview1");
p1=lookup_widget(gestion,"treeview2");
p2=lookup_widget(gestion,"treeview3");
i=0;
j=0;
k=0;
AfficherClient(p,"clients.txt");
AfficherClient1(p1,"clients.txt");
AfficherExcursion(p2,"excursions.txt");*/
gtk_widget_show (gestion);
}


void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (acceuil);
gtk_widget_destroy (gestion);

}


void
on_Ajouter_utilisateur_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
 utilisateur c;
GtkWidget *entryNom;
GtkWidget *entryCin;
GtkWidget *entryPrenom;
GtkWidget *entryAdresse;
GtkWidget *entryNumtel;
GtkWidget *labelCin;
GtkWidget *labelnom;
GtkWidget *labelprenom;
GtkWidget *labeladresse;
GtkWidget *labelnumtel;
GtkWidget *existe;
GtkWidget *success;
int b=1;



entryCin=lookup_widget(button,"entry5");
entryNom=lookup_widget(button,"entry1");
entryPrenom=lookup_widget(button,"entry2");
entryAdresse=lookup_widget(button,"entry4");
entryNumtel=lookup_widget(button,"entry3");

labelCin=lookup_widget(button,"label13");
labelnom=lookup_widget(button,"label7");
labelprenom=lookup_widget(button,"label8");
labeladresse=lookup_widget(button,"label9");
labelnumtel=lookup_widget(button,"label10");
existe=lookup_widget(button,"label34");
success=lookup_widget(button,"label35");
        strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(entryCin) ) );
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(entryNom) ) );
        strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(entryPrenom) ) );
        strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(entryAdresse) ) );
        strcpy(c.numtel,gtk_entry_get_text(GTK_ENTRY(entryNumtel) ) );

 gtk_widget_hide (success);
// controle saisie
if(strcmp(c.cin,"")==0){
		  gtk_widget_show (labelCin);
b=0;
}
else {
		  gtk_widget_hide(labelCin);
}

if(strcmp(c.nom,"")==0){
		  gtk_widget_show (labelnom);
b=0;
}
else {
		  gtk_widget_hide(labelnom);
}
if(strcmp(c.prenom,"")==0){
		  gtk_widget_show (labelprenom);
b=0;
}
else {
		  gtk_widget_hide(labelprenom);
}
if(strcmp(c.adresse,"")==0){
		  gtk_widget_show (labeladresse);
b=0;
}
else {
		  gtk_widget_hide(labeladresse);
}
if(strcmp(c.numtel,"")==0){
		  gtk_widget_show (labelnumtel);
b=0;
}
else {
		  gtk_widget_hide(labelnumtel);
}



if(b==1){

        if(exist_utilisateur(c.cin)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_utilisateur(c);

						  gtk_widget_show (success);
        }
//mise a jour du treeView
        GtkWidget* p=lookup_widget(button,"treeview1");

        Afficherutilisateur(p,"clients.txt");
}











}


void
on_Modifier_utilisateur_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
utilisateur c;

        strcpy(c.cin,gtk_label_get_text(GTK_LABEL(lookup_widget(gestion,"label20"))));
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry6"))));
        strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry7"))));
        strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry9"))));
        strcpy(c.numtel,gtk_entry_get_text(GTK_ENTRY(lookup_widget(gestion,"entry8"))));


        supprimer_utilisateur(c.cin);
        ajouter_utilisateur(c);
//mise ajour du tree view 
        Afficherutilisateur(lookup_widget(gestion,"treeview1"),"clients.txt");
		gtk_widget_show(lookup_widget(gestion,"label37"));
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *cin;
        gchar *nom;
        gchar *prenom;
        gchar *adresse;
        gchar *numtel;
        int x;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(gestion,"treeview1");
        GtkTreeSelection *selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {
		gtk_widget_hide(lookup_widget(gestion,"label37"));//cacher label modifier avec succees
		
                gtk_tree_model_get (model,&iter,0,&cin,1,&nom,2,&prenom,3,&adresse,4,&numtel,-1);//recuperer les information de la ligne selectionneé
		//remplir les champs de entry
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry6")),nom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry7")),prenom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry9")),adresse);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(gestion,"entry8")),numtel);



                GtkWidget* msgCin=lookup_widget(gestion,"label20");
                GtkWidget* msg1=lookup_widget(gestion,"label36");
                gtk_label_set_text(GTK_LABEL(msgCin),cin);
                gtk_widget_show(msgCin);
                gtk_widget_show(msg1);
                gtk_widget_show(lookup_widget(gestion,"button4"));//afficher le bouton modifier
                gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(gestion,"notebook1")));//redirection vers la page precedente
        }
}


void
on_Supprimer_utilisateur_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *label;
        gchar* cin;//gchar* type gtk ==> chaine en c car la fonction gtk_tree_model_get naccepte que gchar*
        label=lookup_widget(gestion,"label23");
        p=lookup_widget(gestion,"treeview1");




        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))//test sur la ligne selectionnée
        {  gtk_tree_model_get (model,&iter,0,&cin,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

           supprimer_utilisateur(cin);// supprimer la ligne du fichier

           gtk_widget_hide (label);}
else{
                gtk_widget_show (label);
        }
}


void
on_chercher_utilisateur_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelnom;
GtkWidget *nbResultat;
GtkWidget *message;
char nom[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(gestion,"entry10");
labelnom=lookup_widget(gestion,"label28");
p1=lookup_widget(gestion,"treeview2");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(entry)));

if(strcmp(nom,"")==0){
  gtk_widget_show (labelnom);b=0;
}else{
b=1;
gtk_widget_hide (labelnom);}

if(b==0){return;}else{

nb=Chercherutilisateur(p1,"clients.txt",nom);
/* afficher le nombre de resultats obtenue par la recherche */
sprintf(chnb,"%d",nb);//conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultat=lookup_widget(gestion,"label27");
message=lookup_widget(gestion,"label26");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);



}
}


void
on_Reserver_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget* p;
        GtkWidget *labelSelection;
        GtkWidget *labelInvalid;
        GtkWidget *labelsuccess;

        int nbPlaceDispo,prix,nbE;
       gchar *date_depart;
        gchar *date_retour;
        gchar *destination;
	excursion e;


        labelSelection=lookup_widget(gestion,"label43");
        labelInvalid=lookup_widget(gestion,"label44");
        labelsuccess=lookup_widget(gestion,"label45");
        p=lookup_widget(gestion,"treeview3");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  
                gtk_tree_model_get (model,&iter,0,&date_depart,1,&date_retour,2,&destination,3,&nbPlaceDispo,4,&prix,-1);//recuperer les information de la ligne selectionneé
		//remplissage du structure utilisateur
		strcpy(e.date_depart,date_depart);
		strcpy(e.date_retour,date_retour);
		strcpy(e.destination,destination);
		e.prix=prix;
		e.nbPlaceDispo=nbPlaceDispo;
		nbE =gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (lookup_widget(gestion,"spinbutton1")));



		if(e.nbPlaceDispo<nbE){

		gtk_widget_show (labelInvalid);

		}else
		{
		gtk_widget_hide(labelInvalid);


		ajouter_reservation(e,nbE);
		modifier_excursion(e,nbE);

		gtk_widget_show (labelsuccess);









		//mise a jour du treeView
		AfficherExcursion(lookup_widget(gestion,"treeview3"),"excursions.txt");

	 	gtk_widget_hide (labelSelection); }

	}else{

                gtk_widget_show (labelSelection);
        }

}

